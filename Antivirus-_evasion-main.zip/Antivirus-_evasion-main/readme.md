
```markdown
# Nim EDR Bypass Payload Builder

This tool builds an executable (`crypted.exe`) that bypasses EDR by adavanced evasion method.


   ```
3. The final executable `crypted.exe` is generated.


```
